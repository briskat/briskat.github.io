drop table author;
drop table "date";
drop table "commit";
drop table file_change_type;
drop table "file";
drop table "fact";
drop table "suffix";

create table author ("id" INTEGER NOT NULL);
create index ON author ("id");

create table "date" ("id" INTEGER NOT NULL);
create index ON "date" ("id");

create table "commit" ("id" INTEGER NOT NULL, "author_id" INTEGER NOT NULL, date_id INTEGER NOT NULL);
create index ON "commit" ("id");
create index ON "commit" ("author_id");
create index ON "commit" ("date_id");

create table file_change_type ("id" INTEGER NOT NULL);
create index ON "file_change_type" ("id");

create table "suffix" ("id" INTEGER NOT NULL);
create index ON "suffix" ("id");

create table "file" ("id" INTEGER NOT NULL, "suffix_id" INTEGER NOT NULL);
create index ON "file" ("id");
create index ON "file" ("suffix_id");

create table "fact" ("id" INTEGER NOT NULL, "commit_id" INTEGER NOT NULL, "file_change_type_id" INTEGER NOT NULL, "file_id" INTEGER NOT NULL, "lines_added" INTEGER, "lines_deleted" INTEGER, "size_changed" INTEGER);
create index ON "fact" ("id");
create index ON "fact" ("commit_id");
create index ON "fact" ("file_change_type_id");
create index ON "fact" ("file_id");
