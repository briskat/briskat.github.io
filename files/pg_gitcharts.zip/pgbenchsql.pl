#!/usr/bin/perl
use strict;
use warnings;
use List::Util qw/shuffle/;
use Getopt::Long qw/:config no_ignore_case/;

# Usage:
# generate client*.txt files with URLs in CWD for bench.sh
# benchurls.pl -days 30 -clients 1

my ($clients, $days);
GetOptions(
	'days=s' => \$days,
	'clients=s' => \$clients,
) or die("Error in command line arguments\n");
#my @days     = ( 1 .. $days );
my @days     = ( 335 .. (335+$days) );
my @projects = (
	'angularjs_angular', 'bootstrap_twbs', 'django_django', 'docker_docker',
	'emberjs_emberjs', 'gcc_gccmirror', 'git_git', 'jekyll_jekyll',
	'jenkins_jenkinsci', 'jquery_jquery', 'linux_torvalds', 'mongo_mongodb',
	'postgres_postgres', 'puppet_puppetlabs', 'rails_rails', 'youtubedl_rg3',
);

#my $day_id=int(time/86400)-10; #current date
my $day_id=16611; # int(time/86400);

for my $cnt ( 1 .. $clients ) {
	my @reqs;
	for my $project ( shuffle @projects ) {
		foreach my $x ( shuffle @days ) {
			my $date_id = $day_id - $x;
			push @reqs, [
				"\\c $project;",
					# last x days
#					"SELECT date_id, COUNT(*) FROM commit WHERE date_id>$date_id GROUP BY date_id;",
#					"SELECT date_id, SUM(size_changed) FROM fact, commit WHERE commit_id=commit.id AND date_id>$date_id GROUP BY date_id;",
#					"SELECT date_id, file_change_type_id, COUNT(*) FROM fact, commit, file_change_type WHERE commit_id=commit.id AND file_change_type_id=file_change_type.id GROUP BY date_id, file_change_type_id HAVING date_id>$date_id;",
#					"SELECT date_id, SUM(lines_added), SUM(lines_deleted) FROM fact, commit WHERE commit_id=commit.id AND date_id>$date_id GROUP BY date_id;",
					# authors
					"SELECT author_id, COUNT(*) AS CNT FROM author, commit WHERE author_id=author.id AND date_id>$date_id GROUP BY author_id ;",
					"SELECT author_id, SUM(size_changed),SUM(lines_added),SUM(lines_deleted)  FROM author, commit, fact WHERE author_id=author.id AND commit.id=commit_id AND date_id>$date_id GROUP BY author_id ;",
			];
		}
	}
	open my $f, ">client$cnt.txt";
	foreach my $r ( @reqs ) {
		print $f shift(@$r) ."\n" for 1..3;
	}
	close $f;
}
