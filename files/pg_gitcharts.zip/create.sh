export PGPASSWORD=FIXME
export ETL=./data

export x=`printf "\x1F"`
for project_dir in $ETL/*
	do
		db=`basename "$project_dir" |tr '[:upper:]' '[:lower:]' | sed -e 's/ (/_/; s/)//; s/[. -]//;'`
		DIR="$project_dir/data/"
		echo $DIR : $db;
		echo "CREATE DATABASE $db OWNER gitcharts;" | psql -U gitcharts
		psql $db  -U gitcharts < pdm.sql
		( echo "COPY author FROM stdin DELIMITER '$x';" ; cat "$DIR"/author.sql ) | psql $db  -U gitcharts
		( echo "COPY commit FROM stdin DELIMITER '$x';" ; cat "$DIR"/commit.sql ) | psql $db  -U gitcharts
		( echo "COPY date FROM stdin DELIMITER '$x';" ; cat "$DIR"/date.sql ) | psql $db  -U gitcharts
		( echo "COPY fact FROM stdin DELIMITER '$x';" ; cat "$DIR"/fact.sql ) | psql $db  -U gitcharts
		( echo "COPY file_change_type FROM stdin DELIMITER '$x';" ; cat "$DIR"/file_change_type.sql ) | psql $db  -U gitcharts
		( echo "COPY file FROM stdin DELIMITER '$x';" ; cat "$DIR"/file.sql ) | psql $db  -U gitcharts
		( echo "COPY suffix FROM stdin DELIMITER '$x';" ; cat "$DIR"/suffix.sql ) | psql $db  -U gitcharts
	done
